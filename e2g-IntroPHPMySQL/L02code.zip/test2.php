<html>
<body>

<?php
$name = "Ima Test";
$age = 100;
$salary = 575.25;
echo "<h2>Information for $name</h2>\n";
echo "Age: $age<br />\n";
echo "Salary: $$salary\n";
?>
</body>
</html>
