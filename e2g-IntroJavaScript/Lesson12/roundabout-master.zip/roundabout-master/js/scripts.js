$(document).ready(function(){
	$('.slider').roundabout({dots: true, infinite: true, speed: 200});
});